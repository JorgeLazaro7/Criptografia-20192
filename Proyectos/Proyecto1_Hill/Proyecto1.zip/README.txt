Primer Proyecto de Criptografía y Seguridad

	Cifrado de Hill

Diana Lucía Guerrero Chávez  308005651
Jorge Alberto Lázaro Arias   412049725

Archivos:
	Hill.java   -     Código fuente del cifrado y descifrado de Hill en el método main se declaran el texto y la llave a usar
	ModMatrix.java -  Clase auxiliar que usamos para calcular la inversa modular de una matriz


Compilar ambos archivos y ejecutar Hill